import Layout from "./components/Layout";
import Home from "./components/Home";
import Listing from "./components/Listing";
import Detail from "./components/Detail";
import Cart from "./components/Cart";
import React, { Component } from "react";
import { Routes, Route} from "react-router-dom";
import Error404 from "./components/404";

class App extends Component {
  constructor(props) {
    super(props);
    this.state = { productsList: [], searchValue: "", isSearch: false };
  }

  componentDidMount() {
    fetch("https://fakestoreapi.com/products")
      .then((res) => res.json())
      .then((data) => this.setState({ productsList: data }));
  }

  handleSearchChange = (data) => {
    this.setState({ searchValue: data, isSearch: true });
  };

  render() {
    return (
      <div>
        <Routes>
          <Route
            path="/"
            element={
              <Layout onHandleSearchChange={this.handleSearchChange}/>
            }
          >
            <Route path="/" element={<Home />} />
            <Route path="/cart" element={<Cart />} />
            <Route
              path="listing"
              element={
                <Listing
                  productName={this.state.searchValue}
                  isSearch={this.state.isSearch}
                />
              }
            />
            <Route path="detail/:id" element={<Detail />} />
          </Route>
          <Route path="*" element={<Error404 />} />

        </Routes>
      </div>
    );
  }
}

// function App() {
//   return (
//     <div>
//       <Header />
//       <Listing />
//       {/* <Home /> */}
//       {/* <Detail /> */}
//       <Footer />
//     </div>
//   );
// }

export default App;
